import React, { useState, useEffect } from 'react';
import { ThemeProvider } from './components/ThemeProvider';
import { ActivityMonitorProvider, useActivityMonitor } from './components/ActivityMonitor';
import { DataProvider } from './components/DataContext';
import { FloatingChatbot } from './components/FloatingChatbot';
import { LoginPage, OperationType } from './components/LoginPage';
import { EntryPage } from './components/EntryPage';
import { ControlCenter } from './components/ControlCenter';
import { DashboardBuilder } from './components/DashboardBuilder';
import { Simulator } from './components/Simulator';
import { WhatIfAnalysis } from './components/WhatIfAnalysis';
import { ReportsPage } from './components/ReportsPage';
import { SettingsPage } from './components/SettingsPage';
import { CourierHub } from './components/CourierHub';
import { WorkforceView } from './components/WorkforceView';
import { EnergyView } from './components/EnergyView';
import { SystemRedesignStudio } from './components/SystemRedesignStudio';
import { CustomizeDashboard } from './components/CustomizeDashboard';

import { BottomNavigation } from './components/BottomNavigation';
import { OperationSwitcher } from './components/OperationSwitcher';
import { Toaster } from './components/ui/sonner';

export type AppPage = 'login' | 'entry' | 'home' | 'dashboard' | 'simulator' | 'reports' | 'settings' | 'whatif' | 'courier' | 'workforce' | 'energy' | 'redesign' | 'customize';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<AppPage>('login');
  const [selectedOperation, setSelectedOperation] = useState<OperationType | null>(null);
  const { logActivity } = useActivityMonitor();

  // Log page navigation activity
  useEffect(() => {
    if (currentPage !== 'login' && currentPage !== 'entry') {
      logActivity(
        'Page Navigation',
        getPageDisplayName(currentPage),
        `User navigated to ${getPageDisplayName(currentPage)} page`
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentPage]); // logActivity is memoized in context

  const getPageDisplayName = (page: AppPage): string => {
    const pageNames = {
      'login': 'Login',
      'entry': 'Entry Page',
      'home': 'Control Center',
      'dashboard': 'Dashboard Builder',
      'simulator': 'Simulator',
      'whatif': 'What-If Analysis',
      'reports': 'Reports',
      'settings': 'Settings',
      'courier': 'Courier Hub',
      'workforce': 'Workforce Management',
      'energy': 'Energy Management',
      'redesign': 'System Redesign Studio',
      'customize': 'Customize My Dashboard'
    };
    return pageNames[page] || page;
  };

  const handleOperationSelect = (operation: OperationType) => {
    setSelectedOperation(operation);
    // Navigate to the main page based on operation type
    switch (operation) {
      case 'terminal':
        setCurrentPage('entry');
        break;
      case 'courier':
        setCurrentPage('courier');
        break;
      case 'workforce':
        setCurrentPage('workforce');
        break;
      case 'energy':
        setCurrentPage('energy');
        break;
      default:
        setCurrentPage('entry');
    }
  };

  const handleStartSimulation = () => {
    setCurrentPage('home');
  };

  const handleOperationSwitch = (operation: OperationType) => {
    setSelectedOperation(operation);
    // Navigate to the main page based on operation type
    switch (operation) {
      case 'terminal':
        setCurrentPage('home');
        break;
      case 'courier':
        setCurrentPage('courier');
        break;
      case 'workforce':
        setCurrentPage('workforce');
        break;
      case 'energy':
        setCurrentPage('energy');
        break;
      default:
        setCurrentPage('home');
    }
  };

  // Get available pages based on operation type
  const getAvailablePages = (): AppPage[] => {
    if (!selectedOperation) return [];
    
    switch (selectedOperation) {
      case 'terminal':
        return ['home', 'dashboard', 'simulator', 'whatif', 'reports', 'settings'];
      case 'courier':
        return ['courier', 'dashboard', 'simulator', 'whatif', 'reports', 'settings'];
      case 'workforce':
        return ['workforce', 'dashboard', 'simulator', 'whatif', 'reports', 'settings'];
      case 'energy':
        return ['energy', 'dashboard', 'simulator', 'whatif', 'reports', 'settings'];
      default:
        return ['simulator', 'reports', 'settings'];
    }
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'login':
        return <LoginPage onOperationSelect={handleOperationSelect} />;
      case 'entry':
        return <EntryPage onStartSimulation={handleStartSimulation} />;
      case 'home':
        return <ControlCenter onNavigate={setCurrentPage} />;
      case 'dashboard':
        return <DashboardBuilder onNavigate={setCurrentPage} operationType={selectedOperation || 'terminal'} />;
      case 'simulator':
        return <Simulator onNavigate={setCurrentPage} operationType={selectedOperation || 'terminal'} />;
      case 'whatif':
        return <WhatIfAnalysis onNavigate={setCurrentPage} />;
      case 'reports':
        return <ReportsPage onNavigate={setCurrentPage} operationType={selectedOperation || 'terminal'} />;
      case 'settings':
        return <SettingsPage onNavigate={setCurrentPage} operationType={selectedOperation || 'terminal'} />;
      case 'courier':
        return <CourierHub onNavigate={setCurrentPage} />;
      case 'workforce':
        return <WorkforceView onNavigate={setCurrentPage} />;
      case 'energy':
        return <EnergyView onNavigate={setCurrentPage} />;
      case 'redesign':
        return <SystemRedesignStudio onNavigate={setCurrentPage} />;
      case 'customize':
        return <CustomizeDashboard onNavigate={setCurrentPage} />;
      default:
        return <ControlCenter onNavigate={setCurrentPage} />;
    }
  };

  const showBottomNav = currentPage !== 'login' && currentPage !== 'entry' && currentPage !== 'whatif' && currentPage !== 'redesign' && currentPage !== 'customize';
  const showOperationSwitcher = selectedOperation && currentPage !== 'login' && currentPage !== 'entry';

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {showOperationSwitcher && (
        <OperationSwitcher 
          currentOperation={selectedOperation}
          onOperationChange={handleOperationSwitch}
        />
      )}
      <div className={`flex-1 ${showBottomNav ? 'pb-16' : ''}`}>
        {renderCurrentPage()}
      </div>
      {showBottomNav && (
        <BottomNavigation 
          currentPage={currentPage} 
          onNavigate={setCurrentPage}
          availablePages={getAvailablePages()}
          selectedOperation={selectedOperation}
        />
      )}
      {/* Floating Chatbot - show on all pages except login and entry */}
      {currentPage !== 'login' && currentPage !== 'entry' && (
        <FloatingChatbot 
          onWorkflowChange={handleOperationSwitch}
          currentOperation={selectedOperation || undefined}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ActivityMonitorProvider>
        <DataProvider>
          <AppContent />
          <Toaster />
        </DataProvider>
      </ActivityMonitorProvider>
    </ThemeProvider>
  );
}