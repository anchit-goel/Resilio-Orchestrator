import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { 
  ArrowLeft,
  Save,
  RotateCcw,
  Eye,
  Brain,
  BarChart3,
  PieChart,
  Activity,
  TrendingUp,
  Gauge,
  Zap,
  FileText,
  Download,
  Users,
  Play,
  Clock,
  AlertCircle,
  CheckCircle,
  Target,
  Settings,
  Lightbulb,
  Search,
  Filter,
  Layout,
  MessageSquare,
  BarChart2,
  PieChart as PieChartIcon,
  Map,
  Calendar
} from 'lucide-react';
import { AppPage } from '../App';

interface CustomizeDashboardProps {
  onNavigate: (page: AppPage) => void;
}

interface DashboardFeature {
  id: string;
  name: string;
  description: string;
  category: 'ai' | 'charts' | 'simulator' | 'reports';
  icon: React.ComponentType<{ className?: string }>;
  enabled: boolean;
  previewComponent?: React.ReactNode;
}

interface FeatureCategory {
  id: string;
  name: string;
  description: string;
  features: string[];
}

export function CustomizeDashboard({ onNavigate }: CustomizeDashboardProps) {
  const [hasChanges, setHasChanges] = useState(false);

  const categories: FeatureCategory[] = [
    {
      id: 'ai',
      name: 'AI & Intelligence',
      description: 'Smart insights and predictive analytics',
      features: ['ai-assistant', 'predictive-insights', 'whatif-analysis']
    },
    {
      id: 'charts',
      name: 'Charts',
      description: 'Visual data representations',
      features: ['line-charts', 'bar-charts', 'pie-charts', 'kpi-cards', 'heatmap']
    },
    {
      id: 'simulator',
      name: 'Simulator',
      description: 'Simulation and monitoring tools',
      features: ['timeline-view', 'event-log']
    },
    {
      id: 'reports',
      name: 'Reports',
      description: 'Export and benchmarking capabilities',
      features: ['pdf-export', 'benchmarking']
    }
  ];

  const defaultFeatures: DashboardFeature[] = [
    // AI & Intelligence
    {
      id: 'ai-assistant',
      name: 'AI Assistant',
      description: 'Interactive chatbot for insights and guidance',
      category: 'ai',
      icon: MessageSquare,
      enabled: true,
      previewComponent: (
        <div className="bg-primary/10 rounded-lg p-3 border border-primary/20">
          <div className="flex items-center space-x-2 mb-2">
            <MessageSquare className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium">AI Assistant</span>
          </div>
          <p className="text-xs text-muted-foreground">Chat interface visible</p>
        </div>
      )
    },
    {
      id: 'predictive-insights',
      name: 'Predictive Insights',
      description: 'AI-powered forecasting and recommendations',
      category: 'ai',
      icon: Brain,
      enabled: true,
      previewComponent: (
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <div className="flex items-center space-x-2 mb-2">
            <Brain className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium">AI Insights</span>
          </div>
          <p className="text-xs text-muted-foreground">Predictive cards shown</p>
        </div>
      )
    },
    {
      id: 'whatif-analysis',
      name: 'What-If Analysis',
      description: 'Scenario planning and analysis tools',
      category: 'ai',
      icon: Lightbulb,
      enabled: false,
      previewComponent: (
        <div className="bg-purple-50 rounded-lg p-3 border border-purple-200">
          <div className="flex items-center space-x-2 mb-2">
            <Lightbulb className="h-4 w-4 text-purple-600" />
            <span className="text-sm font-medium">What-If Analysis</span>
          </div>
          <p className="text-xs text-muted-foreground">Analysis tools available</p>
        </div>
      )
    },

    // Charts
    {
      id: 'line-charts',
      name: 'Line Charts',
      description: 'Time-series data visualization',
      category: 'charts',
      icon: Activity,
      enabled: true,
      previewComponent: (
        <div className="bg-green-50 rounded-lg p-3 border border-green-200">
          <div className="flex items-center space-x-2 mb-2">
            <Activity className="h-4 w-4 text-green-600" />
            <span className="text-sm font-medium">Line Charts</span>
          </div>
          <div className="h-8 bg-green-100 rounded flex items-end space-x-1 p-1">
            <div className="bg-green-400 w-1 h-2"></div>
            <div className="bg-green-400 w-1 h-4"></div>
            <div className="bg-green-400 w-1 h-3"></div>
            <div className="bg-green-400 w-1 h-6"></div>
          </div>
        </div>
      )
    },
    {
      id: 'bar-charts',
      name: 'Bar Charts',
      description: 'Comparative data visualization',
      category: 'charts',
      icon: BarChart3,
      enabled: true,
      previewComponent: (
        <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
          <div className="flex items-center space-x-2 mb-2">
            <BarChart3 className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium">Bar Charts</span>
          </div>
          <div className="h-8 bg-blue-100 rounded flex items-end space-x-1 p-1">
            <div className="bg-blue-400 w-2 h-4"></div>
            <div className="bg-blue-400 w-2 h-6"></div>
            <div className="bg-blue-400 w-2 h-3"></div>
            <div className="bg-blue-400 w-2 h-5"></div>
          </div>
        </div>
      )
    },
    {
      id: 'pie-charts',
      name: 'Pie Charts',
      description: 'Distribution and proportion charts',
      category: 'charts',
      icon: PieChart,
      enabled: false,
      previewComponent: (
        <div className="bg-orange-50 rounded-lg p-3 border border-orange-200">
          <div className="flex items-center space-x-2 mb-2">
            <PieChart className="h-4 w-4 text-orange-600" />
            <span className="text-sm font-medium">Pie Charts</span>
          </div>
          <div className="w-8 h-8 bg-orange-200 rounded-full"></div>
        </div>
      )
    },
    {
      id: 'kpi-cards',
      name: 'KPI Cards',
      description: 'Key performance indicator displays',
      category: 'charts',
      icon: Target,
      enabled: true,
      previewComponent: (
        <div className="bg-indigo-50 rounded-lg p-3 border border-indigo-200">
          <div className="flex items-center space-x-2 mb-2">
            <Target className="h-4 w-4 text-indigo-600" />
            <span className="text-sm font-medium">KPI Cards</span>
          </div>
          <div className="grid grid-cols-2 gap-1">
            <div className="bg-indigo-100 rounded h-4"></div>
            <div className="bg-indigo-100 rounded h-4"></div>
          </div>
        </div>
      )
    },
    {
      id: 'heatmap',
      name: 'Heatmap',
      description: 'Activity density visualization',
      category: 'charts',
      icon: Map,
      enabled: false,
      previewComponent: (
        <div className="bg-red-50 rounded-lg p-3 border border-red-200">
          <div className="flex items-center space-x-2 mb-2">
            <Map className="h-4 w-4 text-red-600" />
            <span className="text-sm font-medium">Heatmap</span>
          </div>
          <div className="grid grid-cols-4 gap-1">
            {[1,2,3,4,5,6,7,8].map(i => (
              <div key={i} className="bg-red-200 h-2 w-2 rounded"></div>
            ))}
          </div>
        </div>
      )
    },

    // Simulator
    {
      id: 'timeline-view',
      name: 'Timeline',
      description: 'Chronological event visualization',
      category: 'simulator',
      icon: Clock,
      enabled: true,
      previewComponent: (
        <div className="bg-cyan-50 rounded-lg p-3 border border-cyan-200">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="h-4 w-4 text-cyan-600" />
            <span className="text-sm font-medium">Timeline View</span>
          </div>
          <div className="space-y-1">
            <div className="bg-cyan-200 h-1 w-full rounded"></div>
            <div className="bg-cyan-200 h-1 w-3/4 rounded"></div>
          </div>
        </div>
      )
    },
    {
      id: 'event-log',
      name: 'Event Log',
      description: 'Detailed activity tracking',
      category: 'simulator',
      icon: FileText,
      enabled: true,
      previewComponent: (
        <div className="bg-teal-50 rounded-lg p-3 border border-teal-200">
          <div className="flex items-center space-x-2 mb-2">
            <FileText className="h-4 w-4 text-teal-600" />
            <span className="text-sm font-medium">Event Log</span>
          </div>
          <div className="space-y-1">
            <div className="bg-teal-200 h-1 w-full rounded"></div>
            <div className="bg-teal-200 h-1 w-5/6 rounded"></div>
            <div className="bg-teal-200 h-1 w-2/3 rounded"></div>
          </div>
        </div>
      )
    },

    // Reports
    {
      id: 'pdf-export',
      name: 'PDF Export',
      description: 'Generate downloadable reports',
      category: 'reports',
      icon: Download,
      enabled: true,
      previewComponent: (
        <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
          <div className="flex items-center space-x-2 mb-2">
            <Download className="h-4 w-4 text-gray-600" />
            <span className="text-sm font-medium">PDF Export</span>
          </div>
          <p className="text-xs text-muted-foreground">Export button available</p>
        </div>
      )
    },
    {
      id: 'benchmarking',
      name: 'Benchmarking',
      description: 'Performance comparison tools',
      category: 'reports',
      icon: TrendingUp,
      enabled: false,
      previewComponent: (
        <div className="bg-yellow-50 rounded-lg p-3 border border-yellow-200">
          <div className="flex items-center space-x-2 mb-2">
            <TrendingUp className="h-4 w-4 text-yellow-600" />
            <span className="text-sm font-medium">Benchmarking</span>
          </div>
          <p className="text-xs text-muted-foreground">Comparison charts shown</p>
        </div>
      )
    }
  ];

  const [features, setFeatures] = useState<DashboardFeature[]>(defaultFeatures);

  const toggleFeature = (featureId: string) => {
    setFeatures(prev => prev.map(feature => 
      feature.id === featureId 
        ? { ...feature, enabled: !feature.enabled }
        : feature
    ));
    setHasChanges(true);
  };

  const handleApplySelection = () => {
    setHasChanges(false);
    // Save preferences to localStorage or backend
    localStorage.setItem('dashboardFeatures', JSON.stringify(features));
    console.log('Dashboard preferences applied:', features.filter(f => f.enabled));
  };

  const handleResetToDefault = () => {
    setFeatures(defaultFeatures);
    setHasChanges(true);
  };

  const enabledFeatures = features.filter(f => f.enabled);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top Bar */}
      <div className="border-b border-border bg-card">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm" onClick={() => onNavigate('home')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-lg font-semibold">Customize Dashboard</h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={handleApplySelection}>
              <Save className="h-4 w-4 mr-2" />
              Save
            </Button>
            <Button 
              size="sm" 
              onClick={handleApplySelection}
              disabled={!hasChanges}
              className="min-w-[100px]"
            >
              Apply
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel - Feature List */}
        <div className="w-1/2 border-r border-border bg-card">
          <ScrollArea className="h-full">
            <div className="p-6 space-y-6">
              {categories.map((category) => {
                const categoryFeatures = features.filter(f => category.features.includes(f.id));
                const enabledCount = categoryFeatures.filter(f => f.enabled).length;
                
                return (
                  <div key={category.id} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">{category.name}</h3>
                        <p className="text-sm text-muted-foreground">{category.description}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {enabledCount}/{categoryFeatures.length}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      {categoryFeatures.map((feature) => {
                        const Icon = feature.icon;
                        return (
                          <div 
                            key={feature.id}
                            className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
                          >
                            <div className="flex items-center space-x-3">
                              <div className="w-8 h-8 bg-muted rounded-lg flex items-center justify-center">
                                <Icon className="h-4 w-4 text-muted-foreground" />
                              </div>
                              <div>
                                <p className="font-medium text-sm">{feature.name}</p>
                                <p className="text-xs text-muted-foreground">{feature.description}</p>
                              </div>
                            </div>
                            <Switch
                              checked={feature.enabled}
                              onCheckedChange={() => toggleFeature(feature.id)}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Right Panel - Live Preview */}
        <div className="w-1/2 bg-background">
          <div className="p-6">
            <div className="mb-4">
              <h3 className="font-medium mb-2">Live Preview</h3>
              <p className="text-sm text-muted-foreground">
                {enabledFeatures.length} features selected • Changes apply instantly
              </p>
            </div>
            
            <Card className="h-[calc(100vh-200px)]">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center space-x-2">
                  <Layout className="h-4 w-4" />
                  <span>Dashboard Preview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[calc(100vh-280px)]">
                  {enabledFeatures.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-32 text-center">
                      <Eye className="h-8 w-8 text-muted-foreground mb-2" />
                      <p className="text-sm text-muted-foreground">
                        No features selected
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Enable features to see preview
                      </p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                      {enabledFeatures.map((feature) => (
                        <div key={feature.id}>
                          {feature.previewComponent}
                        </div>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Bottom Sticky Bar */}
      <div className="border-t border-border bg-card p-4">
        <div className="flex items-center justify-between">
          <Button 
            variant="outline" 
            onClick={handleResetToDefault}
            className="flex items-center space-x-2"
          >
            <RotateCcw className="h-4 w-4" />
            <span>Reset to Default</span>
          </Button>
          
          <div className="flex items-center space-x-4">
            {hasChanges && (
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <AlertCircle className="h-4 w-4 text-yellow-500" />
                <span>Unsaved changes</span>
              </div>
            )}
            <Button 
              onClick={handleApplySelection}
              disabled={!hasChanges}
              className="bg-primary hover:bg-primary/90 min-w-[120px]"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Apply Selection
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}