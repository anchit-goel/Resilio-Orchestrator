import React, { useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { useActivityMonitor } from './ActivityMonitor';
import { 
  Users, 
  Truck, 
  Zap, 
  Play, 
  Pause, 
  RotateCcw,
  BarChart3,
  Brain,
  FileText,
  ChevronRight,
  Target
} from 'lucide-react';
import { AppPage } from '../App';

interface ControlCenterProps {
  onNavigate: (page: AppPage) => void;
}

export function ControlCenter({ onNavigate }: ControlCenterProps) {
  const { logActivity } = useActivityMonitor();
  const [simulationStatus, setSimulationStatus] = React.useState<'running' | 'paused' | 'stopped'>('running');
  const [simulationProgress, setSimulationProgress] = React.useState(67);

  // Log dashboard loading activity
  useEffect(() => {
    logActivity(
      'Dashboard Load',
      'Control Center',
      'User accessed Control Center dashboard with real-time metrics',
      {
        analyzed: ['Terminal status', 'Performance metrics', 'User personas', 'System health'],
        predictions: ['Peak efficiency at 2PM today', 'Terminal A throughput +12%', 'Weather impact minimal'],
        insights: ['Dock 3 highest throughput', 'Staff optimization opportunity at Gate 7', 'Equipment utilization at 89%'],
        dataProcessed: 'Real-time terminal metrics, historical performance data, weather conditions'
      }
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); // logActivity is memoized in context
  
  const personas = [
    {
      id: 'courier',
      title: 'Courier Hub',
      subtitle: 'Delivery Operations',
      icon: Truck,
      color: 'bg-gradient-to-br from-blue-500 to-blue-600',
      stats: { active: 24, efficiency: '94%' }
    },
    {
      id: 'workforce',
      title: 'Workforce View',
      subtitle: 'Staff Management',
      icon: Users,
      color: 'bg-gradient-to-br from-teal-500 to-cyan-600',
      stats: { active: 18, efficiency: '87%' }
    },
    {
      id: 'energy',
      title: 'Energy View',
      subtitle: 'Power Systems',
      icon: Zap,
      color: 'bg-gradient-to-br from-emerald-500 to-teal-600',
      stats: { active: 12, efficiency: '91%' }
    }
  ];

  const quickActions = [
    {
      id: 'customize',
      title: 'Select My Insights',
      subtitle: 'Customize Dashboard Features',
      icon: Target,
      page: 'customize' as AppPage,
      featured: true
    },
    {
      id: 'dashboard',
      title: 'Dashboard Builder',
      subtitle: 'Self-Service Analytics',
      icon: BarChart3,
      page: 'dashboard' as AppPage
    },

    {
      id: 'whatif',
      title: 'What-If Analysis',
      subtitle: 'Scenario Planning',
      icon: Brain,
      page: 'whatif' as AppPage
    },
    {
      id: 'reports',
      title: 'Reports',
      subtitle: 'Export & Share',
      icon: FileText,
      page: 'reports' as AppPage
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-4 sticky top-0 z-10">
        <h1 className="text-foreground">Control Center</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Monitor and manage terminal operations
        </p>
      </div>

      {/* Content */}
      <div className="overflow-auto p-4 space-y-6 pb-20">
        {/* Persona Selector */}
        <section>
          <h2 className="text-slate-700 mb-4">Select Operational View</h2>
          <div className="grid gap-3">
            {personas.map((persona) => {
              const Icon = persona.icon;
              return (
                <Card 
                  key={persona.id} 
                  className="cursor-pointer hover:shadow-md transition-all duration-200 border border-border bg-card"
                  onClick={() => {
                    logActivity(
                      'View Switch',
                      'Control Center',
                      `User switched to ${persona.title} operational view`,
                      {
                        analyzed: [`${persona.title} metrics`, 'User workflow patterns', 'Operational efficiency'],
                        predictions: [`${persona.title} performance trends`, 'Optimal resource allocation'],
                        insights: [`${persona.title} efficiency at ${persona.stats.efficiency}`, 'Active operations monitored'],
                        dataProcessed: 'Operational metrics, efficiency data, active resource counts'
                      }
                    );
                    onNavigate(persona.id as AppPage);
                  }}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <div className={`${persona.color} rounded-xl p-3 flex items-center justify-center`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-card-foreground">{persona.title}</h3>
                        <p className="text-muted-foreground text-sm">{persona.subtitle}</p>
                        <div className="flex items-center space-x-3 mt-2">
                          <Badge variant="secondary" className="text-xs">
                            {persona.stats.active} Active
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {persona.stats.efficiency} Efficiency
                          </Badge>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Simulation Controls */}
        <section>
          <h2 className="text-foreground mb-4">Simulation Controls</h2>
          <Card className="border border-border bg-card">
            <CardContent className="p-4">
              <div className="grid grid-cols-3 gap-3">
                <Button 
                  className={`flex flex-col items-center py-6 text-white ${
                    simulationStatus === 'running' 
                      ? 'bg-gray-500 hover:bg-gray-600' 
                      : 'bg-green-500 hover:bg-green-600'
                  }`}
                  disabled={simulationStatus === 'running'}
                  onClick={() => {
                    setSimulationStatus('running');
                    logActivity(
                      'Simulation Control',
                      'Control Center',
                      'User started terminal simulation',
                      {
                        analyzed: ['Terminal state', 'Resource availability', 'Operational readiness'],
                        predictions: ['Simulation completion in 45 minutes', 'Peak efficiency at 2PM'],
                        insights: ['All systems operational', 'Optimal conditions for simulation'],
                        dataProcessed: 'Real-time terminal metrics, simulation parameters'
                      }
                    );
                  }}
                >
                  <Play className="h-6 w-6 mb-2" />
                  <span className="text-sm">Play</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col items-center py-6"
                  disabled={simulationStatus !== 'running'}
                  onClick={() => {
                    setSimulationStatus('paused');
                    logActivity(
                      'Simulation Control',
                      'Control Center',
                      'User paused terminal simulation',
                      {
                        analyzed: ['Current simulation state', 'Progress metrics'],
                        predictions: ['Resume recommended within 10 minutes'],
                        insights: ['Simulation can be safely paused', 'Current progress preserved'],
                        dataProcessed: 'Simulation state data, progress metrics'
                      }
                    );
                  }}
                >
                  <Pause className="h-6 w-6 mb-2" />
                  <span className="text-sm">Pause</span>
                </Button>
                <Button 
                  variant="outline" 
                  className="flex flex-col items-center py-6"
                  onClick={() => {
                    setSimulationStatus('stopped');
                    setSimulationProgress(0);
                    logActivity(
                      'Simulation Control',
                      'Control Center',
                      'User reset terminal simulation',
                      {
                        analyzed: ['Simulation history', 'Reset requirements'],
                        predictions: ['Fresh simulation ready to start'],
                        insights: ['All progress cleared', 'System ready for new simulation'],
                        dataProcessed: 'Simulation reset data, system state'
                      }
                    );
                  }}
                >
                  <RotateCcw className="h-6 w-6 mb-2" />
                  <span className="text-sm">Reset</span>
                </Button>
              </div>
              <div className="mt-4 p-3 bg-primary/5 rounded-lg">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Simulation Status</span>
                  <Badge className={
                    simulationStatus === 'running' ? 'bg-green-100 text-green-700' :
                    simulationStatus === 'paused' ? 'bg-yellow-100 text-yellow-700' :
                    'bg-gray-100 text-gray-700'
                  }>
                    {simulationStatus === 'running' ? 'Running' :
                     simulationStatus === 'paused' ? 'Paused' : 'Stopped'}
                  </Badge>
                </div>
                <div className="mt-2 bg-muted rounded-full h-2 overflow-hidden">
                  <div 
                    className={`h-full rounded-full transition-all duration-500 ${
                      simulationStatus === 'running' ? 'bg-gradient-to-r from-primary to-cyan-600' :
                      simulationStatus === 'paused' ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
                      'bg-gray-400'
                    }`}
                    style={{ width: `${simulationProgress}%` }}
                  ></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {simulationStatus === 'stopped' ? 'Ready to start new simulation' :
                   simulationStatus === 'paused' ? 'Simulation paused • Progress saved' :
                   'Day 3 of 5 • 14:32 simulated time'}
                </p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Quick Actions */}
        <section>
          <h2 className="text-foreground mb-4">Quick Actions</h2>
          <div className="grid gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Card 
                  key={action.id} 
                  className={`cursor-pointer hover:shadow-md transition-all duration-200 border border-border bg-card ${
                    action.featured ? 'ring-2 ring-primary/20 bg-gradient-to-r from-primary/5 to-transparent' : ''
                  }`}
                  onClick={() => {
                    logActivity(
                      'Quick Action',
                      'Control Center',
                      `User clicked ${action.title} quick action`,
                      {
                        analyzed: [`${action.title} requirements`, 'User workflow patterns', 'System readiness'],
                        predictions: [`${action.title} completion probability: 94%`, 'Optimal usage time detected'],
                        insights: [`${action.title} most effective for current operations`, 'Recommended next steps identified'],
                        dataProcessed: 'User interaction history, system performance metrics'
                      }
                    );
                    onNavigate(action.page);
                  }}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <div className={`${action.featured ? 'bg-gradient-to-br from-primary to-red-600' : 'bg-gradient-to-br from-primary to-red-600'} rounded-lg p-3 flex items-center justify-center`}>
                        <Icon className="h-5 w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-card-foreground flex items-center">
                          {action.title}
                          {action.featured && (
                            <Badge variant="outline" className="ml-2 text-xs border-primary text-primary">
                              Featured
                            </Badge>
                          )}
                        </h3>
                        <p className="text-muted-foreground text-sm">{action.subtitle}</p>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      </div>
    </div>
  );
}