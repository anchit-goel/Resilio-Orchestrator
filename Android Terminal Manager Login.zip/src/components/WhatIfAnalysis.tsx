import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Slider } from './ui/slider';
import { Badge } from './ui/badge';
import { 
  ArrowLeft,
  Mic,
  Brain,
  TrendingUp,
  TrendingDown,
  Users,
  Package,
  Clock,
  Save
} from 'lucide-react';
import { AppPage } from '../App';

interface WhatIfAnalysisProps {
  onNavigate: (page: AppPage) => void;
}

interface KPIComparison {
  name: string;
  baseline: number;
  scenario: number;
  unit: string;
  format: 'number' | 'percentage' | 'time';
}

export function WhatIfAnalysis({ onNavigate }: WhatIfAnalysisProps) {
  const [workforcePercent, setWorkforcePercent] = useState([100]);
  const [parcelVolume, setParcelVolume] = useState([100]);
  const [bayCapacity, setBayCapacity] = useState([100]);
  const [query, setQuery] = useState('');

  const kpiComparisons: KPIComparison[] = [
    { name: 'Throughput', baseline: 2847, scenario: 3200, unit: 'packages/hour', format: 'number' },
    { name: 'Processing Time', baseline: 3.2, scenario: 2.8, unit: 'minutes', format: 'time' },
    { name: 'Efficiency', baseline: 87, scenario: 92, unit: '%', format: 'percentage' },
    { name: 'Queue Length', baseline: 45, scenario: 32, unit: 'packages', format: 'number' },
  ];

  const formatValue = (value: number, format: KPIComparison['format'], unit: string) => {
    switch (format) {
      case 'percentage':
        return `${value}${unit}`;
      case 'time':
        return `${value} ${unit}`;
      default:
        return `${value.toLocaleString()} ${unit}`;
    }
  };

  const getChangeIcon = (baseline: number, scenario: number) => {
    if (scenario > baseline) return TrendingUp;
    if (scenario < baseline) return TrendingDown;
    return TrendingUp;
  };

  const getChangeColor = (baseline: number, scenario: number, isGoodWhenHigher = true) => {
    const isIncrease = scenario > baseline;
    const isGood = isGoodWhenHigher ? isIncrease : !isIncrease;
    return isGood ? 'text-green-600' : 'text-red-600';
  };

  const sampleQuestions = [
    "What if we increase workforce by 25%?",
    "How would 50% more packages affect processing time?",
    "What's the impact of reducing bay capacity by 20%?"
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center space-x-3 mb-4">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onNavigate('home')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-slate-800">Scenario Planning</h1>
            <p className="text-muted-foreground text-sm">What-if analysis with AI insights</p>
          </div>
        </div>

        {/* AI Query Box */}
        <div className="space-y-3">
          <div className="relative">
            <Input
              placeholder="Type or speak your What-If question..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pr-12"
            />
            <Button 
              size="sm" 
              className="absolute right-1 top-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-lg"
            >
              <Mic className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Sample Questions */}
          <div className="flex flex-wrap gap-2">
            {sampleQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs h-auto py-2 px-3"
                onClick={() => setQuery(question)}
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-6 pb-20">
        {/* Parameter Sliders */}
        <section>
          <h2 className="text-slate-700 mb-4 flex items-center">
            <Brain className="h-5 w-5 mr-2" />
            Scenario Parameters
          </h2>
          
          <div className="space-y-4">
            <Card className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-blue-600" />
                    <span className="text-sm font-medium text-slate-700">Workforce Level</span>
                  </div>
                  <Badge variant="secondary">{workforcePercent[0]}%</Badge>
                </div>
                <Slider
                  value={workforcePercent}
                  onValueChange={setWorkforcePercent}
                  max={150}
                  min={50}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>50%</span>
                  <span>100%</span>
                  <span>150%</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Package className="h-4 w-4 text-teal-600" />
                    <span className="text-sm font-medium text-slate-700">Parcel Volume</span>
                  </div>
                  <Badge variant="secondary">{parcelVolume[0]}%</Badge>
                </div>
                <Slider
                  value={parcelVolume}
                  onValueChange={setParcelVolume}
                  max={200}
                  min={50}
                  step={10}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>50%</span>
                  <span>100%</span>
                  <span>200%</span>
                </div>
              </CardContent>
            </Card>

            <Card className="border border-border">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-purple-600" />
                    <span className="text-sm font-medium text-slate-700">Bay Capacity</span>
                  </div>
                  <Badge variant="secondary">{bayCapacity[0]}%</Badge>
                </div>
                <Slider
                  value={bayCapacity}
                  onValueChange={setBayCapacity}
                  max={150}
                  min={70}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>70%</span>
                  <span>100%</span>
                  <span>150%</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* KPI Comparison */}
        <section>
          <h2 className="text-slate-700 mb-4">Before vs After Impact</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {kpiComparisons.map((kpi) => {
              const ChangeIcon = getChangeIcon(kpi.baseline, kpi.scenario);
              const changePercent = Math.abs(((kpi.scenario - kpi.baseline) / kpi.baseline) * 100).toFixed(1);
              const isGoodChange = kpi.name === 'Processing Time' ? kpi.scenario < kpi.baseline : kpi.scenario > kpi.baseline;
              
              return (
                <Card key={kpi.name} className="border border-border">
                  <CardContent className="p-4">
                    <h3 className="text-sm font-medium text-slate-700 mb-3">{kpi.name}</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Baseline</span>
                        <span className="text-sm text-slate-600">
                          {formatValue(kpi.baseline, kpi.format, kpi.unit)}
                        </span>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground">Scenario</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-slate-800">
                            {formatValue(kpi.scenario, kpi.format, kpi.unit)}
                          </span>
                          <div className={`flex items-center space-x-1 ${getChangeColor(kpi.baseline, kpi.scenario, kpi.name !== 'Processing Time')}`}>
                            <ChangeIcon className="h-3 w-3" />
                            <span className="text-xs">{changePercent}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>

        {/* Forecast Graph Placeholder */}
        <section>
          <Card className="border border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-slate-700">Forecast Comparison</CardTitle>
            </CardHeader>
            <CardContent className="h-40 bg-gradient-to-r from-blue-50 to-teal-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-4 mb-2">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-blue-400 rounded"></div>
                    <span className="text-xs text-slate-600">Baseline</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-teal-400 rounded"></div>
                    <span className="text-xs text-slate-600">Scenario</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">Interactive forecast visualization</p>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Save Scenario */}
        <div className="pb-4">
          <Button className="w-full bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white">
            <Save className="h-4 w-4 mr-2" />
            Save Scenario
          </Button>
        </div>
      </div>
    </div>
  );
}