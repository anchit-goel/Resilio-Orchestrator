import React, { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useDataContext, DatasetColumn } from './DataContext';
import { ImportModal } from './ImportModal';
import { toast } from 'sonner@2.0.3';
import { 
  ArrowLeft,
  Plus,
  BarChart3,
  LineChart,
  PieChart,
  Layout,
  Layers,
  Hash,
  Calendar,
  Database,
  TrendingUp,
  Trash2,
  Eye,
  EyeOff,
  AreaChart,
  Gauge,
  Save,
  X,
  Upload
} from 'lucide-react';
import { AppPage } from '../App';
import { OperationType } from './LoginPage';

interface DashboardBuilderProps {
  onNavigate: (page: AppPage) => void;
  operationType?: OperationType;
}

interface ChartField {
  id: string;
  name: string;
  type: 'dimension' | 'measure' | 'date' | 'string' | 'number';
  datasetId: string;
  column: DatasetColumn;
}

interface ChartConfig {
  id: string;
  title: string;
  type: 'bar' | 'line' | 'pie' | 'area' | 'scatter' | 'gauge' | 'kpi';
  datasetId: string;
  xAxis: ChartField[];
  yAxis: ChartField[];
  color: ChartField[];
  filters: ChartField[];
  position: { x: number; y: number; w: number; h: number };
  visible: boolean;
  config?: {
    showLegend?: boolean;
    showGrid?: boolean;
    aggregation?: 'sum' | 'avg' | 'count' | 'min' | 'max';
    colors?: string[];
  };
}

const CHART_TYPES = [
  { id: 'bar', name: 'Bar Chart', icon: BarChart3, description: 'Compare categories' },
  { id: 'line', name: 'Line Chart', icon: LineChart, description: 'Show trends over time' },
  { id: 'pie', name: 'Pie Chart', icon: PieChart, description: 'Show proportions' },
  { id: 'area', name: 'Area Chart', icon: AreaChart, description: 'Stacked values over time' },
  { id: 'gauge', name: 'Gauge', icon: Gauge, description: 'Show single value progress' },
  { id: 'kpi', name: 'KPI Card', icon: Layout, description: 'Key performance indicator' },
];

// Field Selection Components
function FieldSelector({ 
  title, 
  description, 
  fields, 
  availableFields,
  onFieldAdd, 
  onFieldRemove, 
  acceptedTypes = [],
  allowMultiple = true
}: { 
  title: string; 
  description: string; 
  fields: ChartField[]; 
  availableFields: ChartField[];
  onFieldAdd: (field: ChartField) => void; 
  onFieldRemove: (fieldId: string) => void;
  acceptedTypes?: string[];
  allowMultiple?: boolean;
}) {
  const [draggedField, setDraggedField] = useState<ChartField | null>(null);
  const getFieldIcon = (fieldType: string) => {
    switch (fieldType) {
      case 'date': return Calendar;
      case 'number': return Hash;
      case 'measure': return TrendingUp;
      case 'dimension': return Layers;
      default: return Database;
    }
  };

  const filteredFields = availableFields.filter(field => 
    acceptedTypes.length === 0 || acceptedTypes.includes(field.type)
  ).filter(field => 
    !fields.find(f => f.id === field.id)
  );

  const handleFieldSelect = (fieldId: string) => {
    const field = availableFields.find(f => f.id === fieldId);
    if (field) {
      onFieldAdd(field);
    }
  };

  const handleDragStart = (e: React.DragEvent, field: ChartField) => {
    setDraggedField(field);
    e.dataTransfer.setData('text/plain', field.id);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const fieldId = e.dataTransfer.getData('text/plain');
    const field = availableFields.find(f => f.id === fieldId);
    
    if (field && !fields.find(f => f.id === field.id)) {
      // Check if field type is accepted
      if (acceptedTypes.length === 0 || acceptedTypes.includes(field.type)) {
        // Check if multiple fields are allowed
        if (allowMultiple || fields.length === 0) {
          onFieldAdd(field);
        }
      }
    }
    setDraggedField(null);
  };

  const handleDragEnd = () => {
    setDraggedField(null);
  };

  return (
    <div className="space-y-3">
      <div>
        <h4 className="text-sm font-medium">{title}</h4>
        <p className="text-xs text-muted-foreground">{description}</p>
      </div>
      
      {/* Drop Zone for Selected Fields */}
      <div 
        className={`min-h-16 border-2 border-dashed rounded-lg p-3 transition-colors ${
          fields.length > 0 ? 'border-primary/30 bg-primary/5' : 'border-muted-foreground/30'
        }`}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
      >
        {fields.length > 0 ? (
          <div className="space-y-2">
            {fields.map((field) => {
              const Icon = getFieldIcon(field.type);
              return (
                <div
                  key={field.id}
                  className="flex items-center justify-between p-2 bg-background rounded-lg border shadow-sm"
                >
                <div className="flex items-center space-x-2 flex-1 min-w-0">
                  <Icon className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground truncate">{field.name}</p>
                    <Badge variant="outline" className="text-xs">
                      {field.type}
                    </Badge>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => onFieldRemove(field.id)}
                  className="h-6 w-6 p-0 text-destructive hover:bg-destructive hover:bg-opacity-10 flex-shrink-0"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center text-muted-foreground">
          <div className="text-xs">Drop fields here or select below</div>
        </div>
      )}
    </div>

    {/* Available Fields for Dragging */}
    <div className="space-y-2">
      <h5 className="text-xs font-medium text-muted-foreground">Available Fields</h5>
      <ScrollArea className="h-32">
        <div className="space-y-1 pr-4">
          {filteredFields.map((field) => {
            const Icon = getFieldIcon(field.type);
            return (
              <div
                key={field.id}
                draggable
                onDragStart={(e) => handleDragStart(e, field)}
                onDragEnd={handleDragEnd}
                className={`flex items-center space-x-2 p-2 bg-muted rounded cursor-move hover:bg-accent transition-colors ${
                  draggedField?.id === field.id ? 'opacity-50' : ''
                }`}
                title="Drag to field area above"
              >
                <Icon className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm flex-1 truncate">{field.name}</span>
                <Badge variant="outline" className="text-xs">
                  {field.type}
                </Badge>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </div>

    {/* Add Field Dropdown */}
      {(allowMultiple || fields.length === 0) && filteredFields.length > 0 && (
        <Select onValueChange={handleFieldSelect}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder={'Add ' + title.toLowerCase() + '...'} />
          </SelectTrigger>
          <SelectContent>
            {filteredFields.map((field) => {
              const Icon = getFieldIcon(field.type);
              return (
                <SelectItem key={field.id} value={field.id}>
                  <div className="flex items-center space-x-2">
                    <Icon className="h-4 w-4 text-muted-foreground" />
                    <span>{field.name}</span>
                    <Badge variant="outline" className="text-xs ml-auto">
                      {field.type}
                    </Badge>
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
      )}

      {/* No fields available message */}
      {filteredFields.length === 0 && fields.length === 0 && (
        <div className="p-3 text-center text-xs text-muted-foreground bg-muted bg-opacity-50 rounded-lg border-2 border-dashed">
          No compatible fields available
        </div>
      )}
    </div>
  );
}

function ChartPreview({ chart, dataFields }: { chart: ChartConfig; dataFields: ChartField[] }) {
  // Generate mock data based on chart configuration
  const generateMockData = () => {
    if (!chart.xAxis.length || !chart.yAxis.length) return [];
    
    const data = [];
    const categories = ['Q1', 'Q2', 'Q3', 'Q4'];
    
    for (let i = 0; i < categories.length; i++) {
      const item: any = {};
      item[chart.xAxis[0].name] = categories[i];
      item[chart.yAxis[0].name] = Math.floor(Math.random() * 100) + 20;
      if (chart.color.length > 0) {
        item[chart.color[0].name] = ['Series A', 'Series B'][i % 2];
      }
      data.push(item);
    }
    
    return data;
  };

  const mockData = generateMockData();

  if (!chart.xAxis.length && !chart.yAxis.length) {
    return (
      <div className="h-40 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <Layout className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Add fields to preview chart</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-40 flex items-center justify-center bg-muted bg-opacity-30 rounded border-2 border-dashed">
      <div className="text-center">
        <div className="w-16 h-16 mx-auto mb-2 bg-primary bg-opacity-20 rounded-lg flex items-center justify-center">
          {React.createElement(
            CHART_TYPES.find(t => t.id === chart.type)?.icon || BarChart3,
            { className: "h-8 w-8 text-primary" }
          )}
        </div>
        <p className="text-sm text-foreground">{chart.title}</p>
        <p className="text-xs text-muted-foreground">
          {mockData.length} data points
        </p>
      </div>
    </div>
  );
}

export function DashboardBuilder({ onNavigate, operationType = 'terminal' }: DashboardBuilderProps) {
  const { datasets, getDatasetsByOperation } = useDataContext();
  const [selectedDataset, setSelectedDataset] = useState<string>('');
  const [charts, setCharts] = useState<ChartConfig[]>([]);
  const [selectedChart, setSelectedChart] = useState<string>('');
  const [newChartType, setNewChartType] = useState<ChartConfig['type']>('bar');
  const [showImportModal, setShowImportModal] = useState<boolean>(false);

  // Get available datasets for the current operation
  const availableDatasets = getDatasetsByOperation(operationType);

  // Create fields from selected dataset
  const availableFields: ChartField[] = React.useMemo(() => {
    if (!selectedDataset) return [];
    
    const dataset = datasets.find(d => d.id === selectedDataset);
    if (!dataset) return [];

    return dataset.columns.map(column => ({
      id: `${dataset.id}_${column.name}`,
      name: column.name,
      type: column.type === 'number' ? 'measure' : 
            column.type === 'date' ? 'date' : 'dimension',
      datasetId: dataset.id,
      column
    }));
  }, [selectedDataset, datasets]);

  const handleAddChart = useCallback(() => {
    if (!selectedDataset) {
      toast.error('Please select a dataset first');
      return;
    }

    const newChart: ChartConfig = {
      id: Date.now().toString(),
      title: `New ${CHART_TYPES.find(t => t.id === newChartType)?.name || 'Chart'}`,
      type: newChartType,
      datasetId: selectedDataset,
      xAxis: [],
      yAxis: [],
      color: [],
      filters: [],
      position: { x: 0, y: 0, w: 4, h: 3 },
      visible: true,
      config: {
        showLegend: true,
        showGrid: true,
        aggregation: 'sum'
      }
    };

    setCharts(prev => [...prev, newChart]);
    setSelectedChart(newChart.id);
    toast.success('Chart added successfully');
  }, [selectedDataset, newChartType]);

  const handleRemoveChart = useCallback((chartId: string) => {
    setCharts(prev => prev.filter(c => c.id !== chartId));
    setSelectedChart('');
    toast.info('Chart removed');
  }, []);

  const handleUpdateChart = useCallback((chartId: string, updates: Partial<ChartConfig>) => {
    setCharts(prev => prev.map(chart => 
      chart.id === chartId ? { ...chart, ...updates } : chart
    ));
  }, []);

  const selectedChartData = charts.find(c => c.id === selectedChart);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => onNavigate('home')}
                className="text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Control Center
              </Button>
              <div>
                <h1 className="text-lg font-semibold">Dashboard Builder</h1>
                <p className="text-sm text-muted-foreground">
                  Create custom analytics dashboards for {operationType} operations
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Save className="h-4 w-4 mr-2" />
                Save Dashboard
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="flex h-[calc(100vh-8rem)]">
        {/* Sidebar */}
        <div className="w-80 border-r bg-card flex flex-col overflow-hidden">
          <div className="p-4 border-b">
            <h2 className="text-sm font-medium mb-3">Dataset Selection</h2>
            <Select value={selectedDataset} onValueChange={setSelectedDataset}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a dataset..." />
              </SelectTrigger>
              <SelectContent>
                {availableDatasets.map((dataset) => (
                  <SelectItem key={dataset.id} value={dataset.id}>
                    <div className="flex flex-col items-start">
                      <span>{dataset.name}</span>
                      <span className="text-xs text-muted-foreground">
                        {dataset.rowCount.toLocaleString()} rows, {dataset.columnCount} columns
                      </span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {availableDatasets.length === 0 && (
              <div className="mt-3 p-3 bg-muted bg-opacity-50 rounded-lg text-center">
                <Database className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No datasets available for {operationType} operations
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Upload a dataset to get started
                </p>
                <Button 
                  size="sm" 
                  className="mt-2"
                  onClick={() => setShowImportModal(true)}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Import Dataset
                </Button>
              </div>
            )}
            
            {/* Import Dataset Button */}
            {availableDatasets.length > 0 && (
              <div className="mt-3">
                <Button 
                  size="sm" 
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowImportModal(true)}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Import More Data
                </Button>
              </div>
            )}
          </div>

          {/* Dataset Details */}
          {selectedDataset && (
            <div className="p-4 border-b flex-shrink-0">
              {(() => {
                const dataset = availableDatasets.find(d => d.id === selectedDataset);
                if (!dataset) return null;
                
                return (
                  <div className="space-y-3">
                    <div>
                      <h3 className="text-sm font-medium">{dataset.name}</h3>
                      <p className="text-xs text-muted-foreground">
                        Uploaded {dataset.uploadDate.toLocaleDateString()}
                      </p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <div className="text-center p-2 bg-muted rounded">
                        <div className="text-lg font-medium">{dataset.rowCount.toLocaleString()}</div>
                        <div className="text-xs text-muted-foreground">Rows</div>
                      </div>
                      <div className="text-center p-2 bg-muted rounded">
                        <div className="text-lg font-medium">{dataset.columnCount}</div>
                        <div className="text-xs text-muted-foreground">Columns</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="text-xs font-medium mb-2">Available Fields</h4>
                      <ScrollArea className="h-32">
                        <div className="space-y-1 pr-4">
                        {dataset.columns.map((col, index) => {
                          const getFieldIcon = (type: string) => {
                            switch (type) {
                              case 'date': return Calendar;
                              case 'number': return Hash;
                              default: return Database;
                            }
                          };
                          const Icon = getFieldIcon(col.type);
                          
                          return (
                            <div key={index} className="flex items-center space-x-2 text-xs">
                              <Icon className="h-3 w-3 text-muted-foreground" />
                              <span className="flex-1 truncate">{col.name}</span>
                              <Badge variant="outline" className="text-xs py-0">
                                {col.type}
                              </Badge>
                            </div>
                          );
                        })}
                        </div>
                      </ScrollArea>
                    </div>

                    <div>
                      <h4 className="text-xs font-medium mb-1">Data Quality</h4>
                      <div className="flex items-center space-x-2">
                        <div className={`w-2 h-2 rounded-full ${
                          dataset.summary.dataQuality === 'excellent' ? 'bg-green-500' :
                          dataset.summary.dataQuality === 'good' ? 'bg-blue-500' :
                          dataset.summary.dataQuality === 'fair' ? 'bg-yellow-500' : 'bg-red-500'
                        }`} />
                        <span className="text-xs capitalize">{dataset.summary.dataQuality}</span>
                        <span className="text-xs text-muted-foreground">
                          ({dataset.summary.completeness}% complete)
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          <div className="p-4 border-b flex-shrink-0">
            <h3 className="text-sm font-medium mb-3">Chart Type</h3>
            <Select value={newChartType} onValueChange={(value: ChartConfig['type']) => setNewChartType(value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CHART_TYPES.map((type) => {
                  const Icon = type.icon;
                  return (
                    <SelectItem key={type.id} value={type.id}>
                      <div className="flex items-center space-x-2">
                        <Icon className="h-4 w-4" />
                        <div>
                          <div>{type.name}</div>
                          <div className="text-xs text-muted-foreground">{type.description}</div>
                        </div>
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {/* Dataset Preview or Chart Configuration */}
          {selectedDataset && !selectedChart && (
            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
              <div className="p-4">
                <h3 className="text-sm font-medium mb-3">Dataset Preview</h3>
                {(() => {
                  const dataset = availableDatasets.find(d => d.id === selectedDataset);
                  if (!dataset) return null;
                  
                  const sampleData = dataset.rawData.slice(0, 5);
                  
                  return (
                    <div className="space-y-3">
                      <div className="text-xs text-muted-foreground">
                        Showing first 5 rows of {dataset.rowCount.toLocaleString()} total
                      </div>
                      
                      <div className="border rounded-lg overflow-hidden">
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs">
                            <thead className="bg-muted">
                              <tr>
                                {dataset.columns.slice(0, 4).map((col, index) => (
                                  <th key={index} className="p-2 text-left font-medium">
                                    <div className="flex items-center space-x-1">
                                      <span className="truncate">{col.name}</span>
                                      <Badge variant="secondary" className="text-xs py-0">
                                        {col.type}
                                      </Badge>
                                    </div>
                                  </th>
                                ))}
                                {dataset.columns.length > 4 && (
                                  <th className="p-2 text-left font-medium text-muted-foreground">
                                    +{dataset.columns.length - 4} more
                                  </th>
                                )}
                              </tr>
                            </thead>
                            <tbody>
                              {sampleData.map((row, rowIndex) => (
                                <tr key={rowIndex} className="border-t">
                                  {dataset.columns.slice(0, 4).map((col, colIndex) => {
                                    const value = row[col.name];
                                    const displayValue = value !== null && value !== undefined 
                                      ? String(value).length > 20 
                                        ? String(value).substring(0, 20) + '...'
                                        : String(value)
                                      : '';
                                    
                                    return (
                                      <td key={colIndex} className="p-2 border-l first:border-l-0">
                                        <div className="truncate" title={String(value)}>
                                          {displayValue}
                                        </div>
                                      </td>
                                    );
                                  })}
                                  {dataset.columns.length > 4 && (
                                    <td className="p-2 border-l text-muted-foreground">...</td>
                                  )}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      
                      <div className="text-center">
                        <Button 
                          size="sm" 
                          onClick={handleAddChart}
                          className="mt-2"
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Create Chart from This Data
                        </Button>
                      </div>
                    </div>
                  );
                })()}
              </div>
              </ScrollArea>
            </div>
          )}

          {/* Chart Configuration */}
          {selectedChart && selectedChartData && (
            <div className="flex-1 overflow-hidden">
              <Tabs defaultValue="fields" className="h-full flex flex-col">
                <TabsList className="mx-4 mt-4">
                  <TabsTrigger value="fields">Fields</TabsTrigger>
                  <TabsTrigger value="preview">Preview</TabsTrigger>
                  <TabsTrigger value="data">Data</TabsTrigger>
                </TabsList>
                
                <TabsContent value="fields" className="flex-1 overflow-hidden">
                  <ScrollArea className="h-full">
                    <div className="p-4 space-y-4 pr-6">
                    <div>
                      <Label htmlFor="chart-title">Chart Title</Label>
                      <Input
                        id="chart-title"
                        value={selectedChartData.title}
                        onChange={(e) => handleUpdateChart(selectedChart, { title: e.target.value })}
                        placeholder="Enter chart title..."
                      />
                    </div>

                    {selectedChartData.type !== 'kpi' && (
                      <FieldSelector
                        title="X-Axis"
                        description="Categories or dimensions"
                        fields={selectedChartData.xAxis}
                        availableFields={availableFields}
                        onFieldAdd={(field) => handleUpdateChart(selectedChart, {
                          xAxis: [...selectedChartData.xAxis, field]
                        })}
                        onFieldRemove={(fieldId) => handleUpdateChart(selectedChart, {
                          xAxis: selectedChartData.xAxis.filter(f => f.id !== fieldId)
                        })}
                        acceptedTypes={['dimension', 'date']}
                        allowMultiple={false}
                      />
                    )}

                    <FieldSelector
                      title={selectedChartData.type === 'kpi' ? 'Value' : 'Y-Axis'}
                      description="Measures or numeric values"
                      fields={selectedChartData.yAxis}
                      availableFields={availableFields}
                      onFieldAdd={(field) => handleUpdateChart(selectedChart, {
                        yAxis: [...selectedChartData.yAxis, field]
                      })}
                      onFieldRemove={(fieldId) => handleUpdateChart(selectedChart, {
                        yAxis: selectedChartData.yAxis.filter(f => f.id !== fieldId)
                      })}
                      acceptedTypes={['measure', 'number']}
                      allowMultiple={selectedChartData.type === 'scatter'}
                    />

                    {selectedChartData.type === 'pie' && (
                      <FieldSelector
                        title="Labels"
                        description="Category labels"
                        fields={selectedChartData.xAxis}
                        availableFields={availableFields}
                        onFieldAdd={(field) => handleUpdateChart(selectedChart, {
                          xAxis: [...selectedChartData.xAxis, field]
                        })}
                        onFieldRemove={(fieldId) => handleUpdateChart(selectedChart, {
                          xAxis: selectedChartData.xAxis.filter(f => f.id !== fieldId)
                        })}
                        acceptedTypes={['dimension']}
                        allowMultiple={false}
                      />
                    )}

                    <FieldSelector
                      title="Color By"
                      description="Group by color (optional)"
                      fields={selectedChartData.color}
                      availableFields={availableFields}
                      onFieldAdd={(field) => handleUpdateChart(selectedChart, {
                        color: [...selectedChartData.color, field]
                      })}
                      onFieldRemove={(fieldId) => handleUpdateChart(selectedChart, {
                        color: selectedChartData.color.filter(f => f.id !== fieldId)
                      })}
                      acceptedTypes={['dimension']}
                      allowMultiple={false}
                    />
                    </div>
                  </ScrollArea>
                </TabsContent>

                <TabsContent value="preview" className="flex-1 p-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-sm">{selectedChartData.title}</CardTitle>
                        <div className="flex items-center space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => handleUpdateChart(selectedChart, { 
                              visible: !selectedChartData.visible 
                            })}
                          >
                            {selectedChartData.visible ? (
                              <Eye className="h-3 w-3" />
                            ) : (
                              <EyeOff className="h-3 w-3" />
                            )}
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ChartPreview chart={selectedChartData} dataFields={availableFields} />
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="data" className="flex-1 p-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm">Source Data</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {(() => {
                        const dataset = availableDatasets.find(d => d.id === selectedChartData.datasetId);
                        if (!dataset) return <div className="text-muted-foreground">No data available</div>;
                        
                        const relevantFields = [
                          ...selectedChartData.xAxis,
                          ...selectedChartData.yAxis,
                          ...selectedChartData.color
                        ];
                        
                        const sampleData = dataset.rawData.slice(0, 10);
                        
                        return (
                          <div className="space-y-3">
                            <div className="text-xs text-muted-foreground">
                              Data from "{dataset.name}" - showing first 10 rows
                            </div>
                            
                            {relevantFields.length > 0 ? (
                              <div className="border rounded-lg overflow-hidden">
                                <div className="overflow-x-auto">
                                  <table className="w-full text-xs">
                                    <thead className="bg-muted">
                                      <tr>
                                        {relevantFields.map((field, index) => (
                                          <th key={index} className="p-2 text-left font-medium">
                                            <div className="flex items-center space-x-1">
                                              <span>{field.name}</span>
                                              <Badge variant="secondary" className="text-xs py-0">
                                                {field.type}
                                              </Badge>
                                            </div>
                                          </th>
                                        ))}
                                      </tr>
                                    </thead>
                                    <tbody>
                                      {sampleData.map((row, rowIndex) => (
                                        <tr key={rowIndex} className="border-t">
                                          {relevantFields.map((field, colIndex) => {
                                            const value = row[field.name];
                                            return (
                                              <td key={colIndex} className="p-2 border-l first:border-l-0">
                                                <div className="truncate">
                                                  {value !== null && value !== undefined ? String(value) : '—'}
                                                </div>
                                              </td>
                                            );
                                          })}
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            ) : (
                              <div className="text-center p-4 text-muted-foreground">
                                <Database className="h-8 w-8 mx-auto mb-2 opacity-50" />
                                <p>Select fields to see data preview</p>
                              </div>
                            )}
                          </div>
                        );
                      })()}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 overflow-auto">
          {!selectedDataset ? (
            <div className="h-full flex items-center justify-center">
              <div className="text-center max-w-md">
                <Database className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-2">No Dataset Selected</h3>
                <p className="text-muted-foreground mb-4">
                  {availableDatasets.length === 0 
                    ? "Import a dataset to start building your dashboard"
                    : "Select a dataset from the sidebar to start building your dashboard"
                  }
                </p>
                {availableDatasets.length === 0 && (
                  <Button onClick={() => setShowImportModal(true)}>
                    <Upload className="h-4 w-4 mr-2" />
                    Import Dataset
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-medium">Dashboard Layout</h2>
                  <p className="text-sm text-muted-foreground">
                    {charts.length} {charts.length === 1 ? 'chart' : 'charts'} configured
                  </p>
                </div>
              </div>

              {/* Charts Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {charts.map((chart) => (
                  <Card 
                    key={chart.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      selectedChart === chart.id ? 'ring-2 ring-primary' : ''
                    }`}
                    onClick={() => setSelectedChart(chart.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium truncate">{chart.title}</h3>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleUpdateChart(chart.id, { visible: !chart.visible });
                            }}
                            className="h-6 w-6 p-0"
                          >
                            {chart.visible ? (
                              <Eye className="h-3 w-3" />
                            ) : (
                              <EyeOff className="h-3 w-3" />
                            )}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleRemoveChart(chart.id);
                            }}
                            className="h-6 w-6 p-0 text-destructive hover:bg-destructive hover:bg-opacity-10"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs">
                          {CHART_TYPES.find(t => t.id === chart.type)?.name}
                        </Badge>
                        {!chart.visible && (
                          <Badge variant="secondary" className="text-xs">Hidden</Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ChartPreview chart={chart} dataFields={availableFields} />
                    </CardContent>
                  </Card>
                ))}
                
                {/* Add New Chart Card */}
                {selectedDataset && (
                  <Card 
                    className="border-2 border-dashed border-muted-foreground border-opacity-30 cursor-pointer hover:border-primary hover:border-opacity-50 hover:bg-primary hover:bg-opacity-5 transition-all"
                    onClick={handleAddChart}
                  >
                    <CardContent className="h-full flex items-center justify-center p-6">
                      <div className="text-center">
                        <Plus className="h-12 w-12 text-muted-foreground text-opacity-40 mx-auto mb-2" />
                        <p className="text-sm text-muted-foreground mb-1">Add New Chart</p>
                        <p className="text-xs text-muted-foreground">
                          {CHART_TYPES.find(t => t.id === newChartType)?.name}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Import Modal */}
      <ImportModal 
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        operationType={operationType}
      />
    </div>
  );
}