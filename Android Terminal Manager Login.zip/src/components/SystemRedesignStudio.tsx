import React, { useState, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Switch } from './ui/switch';
import { 
  Palette,
  Move,
  Copy,
  Trash2,
  Undo,
  Redo,
  Save,
  Play,
  Settings,
  Grid,
  MousePointer,
  BarChart3,
  PieChart,
  Activity,
  Clock,
  Users,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Plus,
  Layers,
  Eye,
  EyeOff,
  Lock,
  Unlock,
  Zap,
  Square,
  Circle,
  Triangle
} from 'lucide-react';
import { AppPage } from '../App';

interface SystemRedesignStudioProps {
  onNavigate: (page: AppPage) => void;
}

interface ComponentItem {
  id: string;
  type: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  category: 'basic' | 'charts' | 'kpi' | 'inputs' | 'automation';
  properties: Record<string, any>;
}

interface CanvasElement {
  id: string;
  type: string;
  name: string;
  x: number;
  y: number;
  width: number;
  height: number;
  properties: Record<string, any>;
  locked: boolean;
  visible: boolean;
}

interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  condition: string;
  action: string;
  enabled: boolean;
}

export function SystemRedesignStudio({ onNavigate }: SystemRedesignStudioProps) {
  const [selectedTool, setSelectedTool] = useState<'pointer' | 'move'>('pointer');
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>([]);
  const [automationRules, setAutomationRules] = useState<AutomationRule[]>([]);
  const [gridSnap, setGridSnap] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(100);
  const [history, setHistory] = useState<CanvasElement[][]>([[]]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const canvasRef = useRef<HTMLDivElement>(null);

  const componentLibrary: ComponentItem[] = [
    // Basic Components
    { id: 'button', type: 'button', name: 'Button', icon: Square, category: 'basic', properties: { text: 'Button', color: 'primary' } },
    { id: 'card', type: 'card', name: 'Card', icon: Square, category: 'basic', properties: { title: 'Card Title', content: 'Card content' } },
    { id: 'input', type: 'input', name: 'Input Field', icon: Square, category: 'inputs', properties: { placeholder: 'Enter text', label: 'Input' } },
    { id: 'select', type: 'select', name: 'Dropdown', icon: Square, category: 'inputs', properties: { options: ['Option 1', 'Option 2'], label: 'Select' } },
    
    // Charts & Visualizations
    { id: 'bar-chart', type: 'chart', name: 'Bar Chart', icon: BarChart3, category: 'charts', properties: { chartType: 'bar', title: 'Bar Chart' } },
    { id: 'pie-chart', type: 'chart', name: 'Pie Chart', icon: PieChart, category: 'charts', properties: { chartType: 'pie', title: 'Pie Chart' } },
    { id: 'line-chart', type: 'chart', name: 'Line Chart', icon: Activity, category: 'charts', properties: { chartType: 'line', title: 'Line Chart' } },
    
    // KPI Components
    { id: 'kpi-card', type: 'kpi', name: 'KPI Card', icon: CheckCircle, category: 'kpi', properties: { title: 'KPI', value: '100', unit: '%' } },
    { id: 'gauge', type: 'gauge', name: 'Gauge', icon: Circle, category: 'kpi', properties: { title: 'Performance', value: 85, max: 100 } },
    { id: 'progress', type: 'progress', name: 'Progress Bar', icon: Square, category: 'kpi', properties: { label: 'Progress', value: 70 } },
    
    // Automation
    { id: 'trigger', type: 'trigger', name: 'Trigger', icon: Zap, category: 'automation', properties: { event: 'onClick', description: 'When clicked' } },
    { id: 'condition', type: 'condition', name: 'Condition', icon: Triangle, category: 'automation', properties: { logic: 'if', condition: 'value > 50' } },
    { id: 'action', type: 'action', name: 'Action', icon: Play, category: 'automation', properties: { action: 'showAlert', message: 'Action triggered' } }
  ];

  const saveToHistory = useCallback((elements: CanvasElement[]) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push([...elements]);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  }, [history, historyIndex]);

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setCanvasElements([...history[historyIndex - 1]]);
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setCanvasElements([...history[historyIndex + 1]]);
    }
  };

  const handleDragStart = (e: React.DragEvent, component: ComponentItem) => {
    e.dataTransfer.setData('component', JSON.stringify(component));
  };

  const handleCanvasDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const componentData = e.dataTransfer.getData('component');
    if (componentData) {
      const component = JSON.parse(componentData);
      const rect = canvasRef.current?.getBoundingClientRect();
      if (rect) {
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const newElement: CanvasElement = {
          id: `${component.type}-${Date.now()}`,
          type: component.type,
          name: component.name,
          x: gridSnap ? Math.round(x / 20) * 20 : x,
          y: gridSnap ? Math.round(y / 20) * 20 : y,
          width: 200,
          height: component.category === 'charts' ? 150 : 60,
          properties: { ...component.properties },
          locked: false,
          visible: true
        };
        
        const newElements = [...canvasElements, newElement];
        setCanvasElements(newElements);
        saveToHistory(newElements);
        setSelectedElement(newElement.id);
      }
    }
  };

  const handleCanvasDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const updateElementProperty = (elementId: string, property: string, value: any) => {
    const newElements = canvasElements.map(el => 
      el.id === elementId 
        ? { ...el, properties: { ...el.properties, [property]: value } }
        : el
    );
    setCanvasElements(newElements);
    saveToHistory(newElements);
  };

  const deleteElement = (elementId: string) => {
    const newElements = canvasElements.filter(el => el.id !== elementId);
    setCanvasElements(newElements);
    saveToHistory(newElements);
    setSelectedElement(null);
  };

  const duplicateElement = (elementId: string) => {
    const element = canvasElements.find(el => el.id === elementId);
    if (element) {
      const newElement: CanvasElement = {
        ...element,
        id: `${element.type}-${Date.now()}`,
        x: element.x + 20,
        y: element.y + 20
      };
      const newElements = [...canvasElements, newElement];
      setCanvasElements(newElements);
      saveToHistory(newElements);
      setSelectedElement(newElement.id);
    }
  };

  const selectedElementData = selectedElement ? canvasElements.find(el => el.id === selectedElement) : null;

  const renderCanvasElement = (element: CanvasElement) => {
    const isSelected = selectedElement === element.id;
    
    return (
      <div
        key={element.id}
        className={`absolute border-2 transition-all cursor-pointer ${
          isSelected ? 'border-primary shadow-lg' : 'border-transparent hover:border-muted-foreground/50'
        } ${!element.visible ? 'opacity-50' : ''}`}
        style={{
          left: element.x,
          top: element.y,
          width: element.width,
          height: element.height
        }}
        onClick={() => setSelectedElement(element.id)}
      >
        <div className="w-full h-full bg-card border border-border rounded-lg p-2 overflow-hidden">
          {element.type === 'button' && (
            <Button className="w-full h-full" variant="default">
              {element.properties.text || 'Button'}
            </Button>
          )}
          {element.type === 'card' && (
            <div className="bg-background border rounded p-2 h-full">
              <p className="font-medium text-sm truncate">{element.properties.title}</p>
              <p className="text-xs text-muted-foreground truncate">{element.properties.content}</p>
            </div>
          )}
          {element.type === 'chart' && (
            <div className="bg-muted/50 rounded h-full flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs text-muted-foreground">{element.properties.title}</p>
              </div>
            </div>
          )}
          {element.type === 'kpi' && (
            <div className="bg-background border rounded p-2 h-full flex flex-col justify-center">
              <p className="text-xs text-muted-foreground">{element.properties.title}</p>
              <p className="text-lg font-bold">{element.properties.value}{element.properties.unit}</p>
            </div>
          )}
          {element.type === 'input' && (
            <div className="space-y-1">
              <Label className="text-xs">{element.properties.label}</Label>
              <Input placeholder={element.properties.placeholder} className="text-xs" />
            </div>
          )}
          {(element.type === 'trigger' || element.type === 'condition' || element.type === 'action') && (
            <div className={`h-full flex items-center justify-center rounded ${
              element.type === 'trigger' ? 'bg-blue-50 dark:bg-blue-950' :
              element.type === 'condition' ? 'bg-yellow-50 dark:bg-yellow-950' :
              'bg-green-50 dark:bg-green-950'
            }`}>
              <div className="text-center">
                <Zap className="h-4 w-4 mx-auto mb-1" />
                <p className="text-xs font-medium">{element.name}</p>
              </div>
            </div>
          )}
        </div>
        
        {/* Selection handles */}
        {isSelected && (
          <>
            <div className="absolute -top-1 -left-1 w-3 h-3 bg-primary rounded-full"></div>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full"></div>
            <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-primary rounded-full"></div>
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-primary rounded-full"></div>
          </>
        )}
      </div>
    );
  };

  return (
    <div className="h-screen bg-background flex flex-col">
      {/* Top Toolbar */}
      <div className="bg-card border-b border-border p-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" onClick={() => onNavigate('settings')}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <h1 className="font-semibold">System Redesign Studio</h1>
        </div>

        <div className="flex items-center space-x-2">
          <Button
            variant={selectedTool === 'pointer' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setSelectedTool('pointer')}
          >
            <MousePointer className="h-4 w-4" />
          </Button>
          <Button
            variant={selectedTool === 'move' ? 'default' : 'ghost'}
            size="sm"
            onClick={() => setSelectedTool('move')}
          >
            <Move className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={undo} disabled={historyIndex <= 0}>
            <Undo className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" onClick={redo} disabled={historyIndex >= history.length - 1}>
            <Redo className="h-4 w-4" />
          </Button>
          <Separator orientation="vertical" className="h-6" />
          <Button variant="ghost" size="sm" onClick={() => setShowGrid(!showGrid)}>
            <Grid className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Eye className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Play className="h-4 w-4 mr-2" />
            Preview
          </Button>
          <Button size="sm">
            <Save className="h-4 w-4 mr-2" />
            Save & Apply
          </Button>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Component Library */}
        <div className="w-64 bg-card border-r border-border flex flex-col">
          <div className="p-4 border-b border-border">
            <h3 className="font-medium mb-3 flex items-center">
              <Palette className="h-4 w-4 mr-2" />
              Components
            </h3>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-4">
              <Tabs defaultValue="basic" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-4">
                  <TabsTrigger value="basic" className="text-xs">Basic</TabsTrigger>
                  <TabsTrigger value="charts" className="text-xs">Charts</TabsTrigger>
                  <TabsTrigger value="automation" className="text-xs">Logic</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basic" className="space-y-2">
                  {componentLibrary
                    .filter(comp => comp.category === 'basic' || comp.category === 'inputs' || comp.category === 'kpi')
                    .map(component => {
                      const Icon = component.icon;
                      return (
                        <div
                          key={component.id}
                          className="p-3 border border-border rounded-lg cursor-move hover:bg-muted/50 transition-colors"
                          draggable
                          onDragStart={(e) => handleDragStart(e, component)}
                        >
                          <div className="flex items-center space-x-2">
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">{component.name}</span>
                          </div>
                        </div>
                      );
                    })}
                </TabsContent>
                
                <TabsContent value="charts" className="space-y-2">
                  {componentLibrary
                    .filter(comp => comp.category === 'charts')
                    .map(component => {
                      const Icon = component.icon;
                      return (
                        <div
                          key={component.id}
                          className="p-3 border border-border rounded-lg cursor-move hover:bg-muted/50 transition-colors"
                          draggable
                          onDragStart={(e) => handleDragStart(e, component)}
                        >
                          <div className="flex items-center space-x-2">
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">{component.name}</span>
                          </div>
                        </div>
                      );
                    })}
                </TabsContent>
                
                <TabsContent value="automation" className="space-y-2">
                  {componentLibrary
                    .filter(comp => comp.category === 'automation')
                    .map(component => {
                      const Icon = component.icon;
                      return (
                        <div
                          key={component.id}
                          className="p-3 border border-border rounded-lg cursor-move hover:bg-muted/50 transition-colors"
                          draggable
                          onDragStart={(e) => handleDragStart(e, component)}
                        >
                          <div className="flex items-center space-x-2">
                            <Icon className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm font-medium">{component.name}</span>
                          </div>
                        </div>
                      );
                    })}
                </TabsContent>
              </Tabs>
            </div>
          </ScrollArea>
        </div>

        {/* Center Canvas */}
        <div className="flex-1 bg-muted/20 relative overflow-hidden">
          <div className="absolute inset-4">
            <div
              ref={canvasRef}
              className={`w-full h-full bg-background rounded-lg border-2 border-dashed border-border relative overflow-hidden ${
                showGrid ? 'bg-grid' : ''
              }`}
              onDrop={handleCanvasDrop}
              onDragOver={handleCanvasDragOver}
              style={{
                backgroundImage: showGrid ? 
                  'radial-gradient(circle, #e2e8f0 1px, transparent 1px)' : 'none',
                backgroundSize: showGrid ? '20px 20px' : 'none'
              }}
            >
              {canvasElements.map(renderCanvasElement)}
              
              {canvasElements.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <Layers className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p className="text-lg font-medium">Drag components here to start designing</p>
                    <p className="text-sm">Build your custom interface with drag-and-drop simplicity</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Sidebar - Properties */}
        <div className="w-80 bg-card border-l border-border flex flex-col">
          <div className="p-4 border-b border-border">
            <h3 className="font-medium flex items-center">
              <Settings className="h-4 w-4 mr-2" />
              Properties
            </h3>
          </div>
          
          <ScrollArea className="flex-1">
            <div className="p-4">
              {selectedElementData ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{selectedElementData.name}</h4>
                    <div className="flex space-x-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const newElements = canvasElements.map(el =>
                            el.id === selectedElementData.id
                              ? { ...el, locked: !el.locked }
                              : el
                          );
                          setCanvasElements(newElements);
                        }}
                      >
                        {selectedElementData.locked ? <Lock className="h-3 w-3" /> : <Unlock className="h-3 w-3" />}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => duplicateElement(selectedElementData.id)}
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteElement(selectedElementData.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>

                  <Separator />

                  {/* Basic Properties */}
                  <div className="space-y-3">
                    <div>
                      <Label className="text-xs">Name</Label>
                      <Input
                        value={selectedElementData.name}
                        onChange={(e) => {
                          const newElements = canvasElements.map(el =>
                            el.id === selectedElementData.id
                              ? { ...el, name: e.target.value }
                              : el
                          );
                          setCanvasElements(newElements);
                        }}
                        className="mt-1"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label className="text-xs">Width</Label>
                        <Input
                          type="number"
                          value={selectedElementData.width}
                          onChange={(e) => {
                            const newElements = canvasElements.map(el =>
                              el.id === selectedElementData.id
                                ? { ...el, width: parseInt(e.target.value) || 0 }
                                : el
                            );
                            setCanvasElements(newElements);
                          }}
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Height</Label>
                        <Input
                          type="number"
                          value={selectedElementData.height}
                          onChange={(e) => {
                            const newElements = canvasElements.map(el =>
                              el.id === selectedElementData.id
                                ? { ...el, height: parseInt(e.target.value) || 0 }
                                : el
                            );
                            setCanvasElements(newElements);
                          }}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Component-specific Properties */}
                  <div className="space-y-3">
                    {selectedElementData.type === 'button' && (
                      <>
                        <div>
                          <Label className="text-xs">Button Text</Label>
                          <Input
                            value={selectedElementData.properties.text || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'text', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Color</Label>
                          <Select
                            value={selectedElementData.properties.color || 'primary'}
                            onValueChange={(value) => updateElementProperty(selectedElementData.id, 'color', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="primary">Primary</SelectItem>
                              <SelectItem value="secondary">Secondary</SelectItem>
                              <SelectItem value="destructive">Destructive</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </>
                    )}

                    {selectedElementData.type === 'card' && (
                      <>
                        <div>
                          <Label className="text-xs">Title</Label>
                          <Input
                            value={selectedElementData.properties.title || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'title', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Content</Label>
                          <Textarea
                            value={selectedElementData.properties.content || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'content', e.target.value)}
                            className="mt-1"
                            rows={3}
                          />
                        </div>
                      </>
                    )}

                    {selectedElementData.type === 'kpi' && (
                      <>
                        <div>
                          <Label className="text-xs">Title</Label>
                          <Input
                            value={selectedElementData.properties.title || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'title', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Value</Label>
                          <Input
                            value={selectedElementData.properties.value || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'value', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Unit</Label>
                          <Input
                            value={selectedElementData.properties.unit || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'unit', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                      </>
                    )}

                    {selectedElementData.type === 'chart' && (
                      <>
                        <div>
                          <Label className="text-xs">Chart Title</Label>
                          <Input
                            value={selectedElementData.properties.title || ''}
                            onChange={(e) => updateElementProperty(selectedElementData.id, 'title', e.target.value)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label className="text-xs">Chart Type</Label>
                          <Select
                            value={selectedElementData.properties.chartType || 'bar'}
                            onValueChange={(value) => updateElementProperty(selectedElementData.id, 'chartType', value)}
                          >
                            <SelectTrigger className="mt-1">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="bar">Bar Chart</SelectItem>
                              <SelectItem value="line">Line Chart</SelectItem>
                              <SelectItem value="pie">Pie Chart</SelectItem>
                              <SelectItem value="area">Area Chart</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Settings className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Select an element to edit properties</p>
                </div>
              )}
            </div>
          </ScrollArea>
        </div>
      </div>
    </div>
  );
}