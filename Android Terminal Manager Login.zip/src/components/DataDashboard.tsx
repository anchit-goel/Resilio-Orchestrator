import React, { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { TouchBackend } from 'react-dnd-touch-backend';
import { DataFieldsPanel } from './dashboard/DataFieldsPanel';
import { VisualizationCanvas } from './dashboard/VisualizationCanvas';
import { ChartTypeSelector } from './dashboard/ChartTypeSelector';
import { ChartRenderer } from './dashboard/ChartRenderer';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  BarChart3, 
  PieChart, 
  LineChart, 
  Database,
  RefreshCcw,
  Download,
  Share2
} from 'lucide-react';

export interface DataField {
  id: string;
  name: string;
  type: 'dimension' | 'measure';
  dataType: 'string' | 'number' | 'date';
}

export interface ChartConfig {
  id: string;
  type: 'bar' | 'line' | 'pie' | 'area';
  xAxis?: DataField[];
  yAxis?: DataField[];
  color?: DataField[];
  title: string;
}

// Detect if we're on mobile for touch backend
const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);

export function DataDashboard() {
  const [charts, setCharts] = useState<ChartConfig[]>([]);
  const [selectedChart, setSelectedChart] = useState<string | null>(null);
  
  // Sample data fields - in a real app, these would come from your data sources
  const dataFields: DataField[] = [
    { id: '1', name: 'Server Name', type: 'dimension', dataType: 'string' },
    { id: '2', name: 'CPU Usage', type: 'measure', dataType: 'number' },
    { id: '3', name: 'Memory Usage', type: 'measure', dataType: 'number' },
    { id: '4', name: 'Network I/O', type: 'measure', dataType: 'number' },
    { id: '5', name: 'Timestamp', type: 'dimension', dataType: 'date' },
    { id: '6', name: 'Status', type: 'dimension', dataType: 'string' },
    { id: '7', name: 'Response Time', type: 'measure', dataType: 'number' },
    { id: '8', name: 'Connection Count', type: 'measure', dataType: 'number' },
    { id: '9', name: 'Error Rate', type: 'measure', dataType: 'number' },
  ];

  const addChart = (chartConfig: Omit<ChartConfig, 'id'>) => {
    const newChart = {
      ...chartConfig,
      id: `chart-${Date.now()}`
    };
    setCharts([...charts, newChart]);
    setSelectedChart(newChart.id);
  };

  const updateChart = (chartId: string, updates: Partial<ChartConfig>) => {
    setCharts(charts.map(chart => 
      chart.id === chartId ? { ...chart, ...updates } : chart
    ));
  };

  const removeChart = (chartId: string) => {
    setCharts(charts.filter(chart => chart.id !== chartId));
    if (selectedChart === chartId) {
      setSelectedChart(null);
    }
  };

  return (
    <DndProvider backend={isMobile ? TouchBackend : HTML5Backend}>
      <div className="min-h-screen bg-black text-green-400 font-mono">
        {/* Header */}
        <header className="bg-gray-900/50 border-b border-green-500/30 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-6 w-6 text-green-400" />
              <div>
                <h1 className="text-green-400">Data Dashboard</h1>
                <p className="text-green-300/60 text-sm">Drag & Drop Analytics</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                className="text-green-400 hover:bg-green-500/20 p-2"
              >
                <RefreshCcw className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-green-400 hover:bg-green-500/20 p-2"
              >
                <Download className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                className="text-green-400 hover:bg-green-500/20 p-2"
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex flex-col h-[calc(100vh-140px)]">
          <Tabs defaultValue="build" className="flex-1 flex flex-col">
            <TabsList className="bg-gray-900/50 border-b border-green-500/30 rounded-none p-0">
              <TabsTrigger 
                value="build" 
                className="bg-transparent text-green-400 data-[state=active]:bg-green-500/20 data-[state=active]:text-green-300 border-b-2 border-transparent data-[state=active]:border-green-400 rounded-none px-6 py-3"
              >
                <Database className="h-4 w-4 mr-2" />
                Build
              </TabsTrigger>
              <TabsTrigger 
                value="view" 
                className="bg-transparent text-green-400 data-[state=active]:bg-green-500/20 data-[state=active]:text-green-300 border-b-2 border-transparent data-[state=active]:border-green-400 rounded-none px-6 py-3"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                View
              </TabsTrigger>
            </TabsList>

            <TabsContent value="build" className="flex-1 flex flex-col p-0 mt-0">
              <div className="flex flex-col xl:flex-row flex-1 h-full">
                {/* Data Fields Panel - Hidden on mobile, collapsible on tablet */}
                <div className="hidden md:block w-full md:w-72 xl:w-80 border-r border-green-500/30 bg-gray-900/30">
                  <DataFieldsPanel dataFields={dataFields} />
                </div>

                {/* Main Canvas Area */}
                <div className="flex-1 flex flex-col min-w-0">
                  {/* Chart Type Selector */}
                  <div className="border-b border-green-500/20 p-2 md:p-4">
                    <ChartTypeSelector 
                      onCreateChart={addChart}
                      selectedChart={selectedChart ? charts.find(c => c.id === selectedChart) : null}
                    />
                  </div>

                  {/* Mobile Data Fields - Show on mobile only */}
                  <div className="md:hidden border-b border-green-500/20 max-h-48 overflow-hidden">
                    <DataFieldsPanel dataFields={dataFields} />
                  </div>

                  {/* Visualization Canvas */}
                  <div className="flex-1 p-2 md:p-4 min-h-0">
                    <VisualizationCanvas
                      charts={charts}
                      selectedChart={selectedChart}
                      onSelectChart={setSelectedChart}
                      onUpdateChart={updateChart}
                      onRemoveChart={removeChart}
                      dataFields={dataFields}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="view" className="flex-1 p-2 md:p-4 mt-0">
              {charts.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <BarChart3 className="h-12 w-12 md:h-16 md:w-16 text-green-400/40 mb-3 md:mb-4" />
                  <h3 className="text-green-300 mb-2 text-sm md:text-base">No Visualizations Created</h3>
                  <p className="text-green-400/60 text-xs md:text-sm mb-4">
                    Switch to Build tab to create your first chart
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4 h-full">
                  {charts.map((chart) => (
                    <Card key={chart.id} className="bg-gray-900/50 border-green-500/30">
                      <CardHeader className="pb-2 p-3 md:p-4">
                        <CardTitle className="text-green-300 text-xs md:text-sm truncate">{chart.title}</CardTitle>
                      </CardHeader>
                      <CardContent className="h-48 md:h-64 p-3 md:p-4">
                        {chart.xAxis?.length || chart.yAxis?.length ? (
                          <ChartRenderer 
                            chart={chart} 
                            dataFields={dataFields} 
                            className="h-full"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full text-green-400/60">
                            <div className="text-center">
                              {chart.type === 'bar' && <BarChart3 className="h-8 w-8 md:h-12 md:w-12 mx-auto mb-2" />}
                              {chart.type === 'line' && <LineChart className="h-8 w-8 md:h-12 md:w-12 mx-auto mb-2" />}
                              {chart.type === 'pie' && <PieChart className="h-8 w-8 md:h-12 md:w-12 mx-auto mb-2" />}
                              <p className="text-xs md:text-sm capitalize">{chart.type} Chart</p>
                              <p className="text-xs text-green-400/40 mt-1">Configure axes to see data</p>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </DndProvider>
  );
}