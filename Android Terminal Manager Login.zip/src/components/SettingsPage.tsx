import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { useTheme } from './ThemeProvider';
import { useActivityMonitor } from './ActivityMonitor';
import { AIActivityReport } from './AIActivityReport';
import { ImportModal } from './ImportModal';
import { DownloadButton } from './DownloadButton';
import { OperationType } from './LoginPage';
import { 
  ArrowLeft,
  Database,
  Palette,
  Brain,
  FileText,
  Download,
  Upload,
  Moon,
  Sun,
  Sparkles,
  ChevronRight,
  Activity,
  Eye,
  Building2,
  Truck,
  Users,
  Zap
} from 'lucide-react';
import { AppPage } from '../App';

interface SettingsPageProps {
  onNavigate: (page: AppPage) => void;
  operationType?: OperationType;
}

export function SettingsPage({ onNavigate, operationType = 'terminal' }: SettingsPageProps) {
  const { theme, toggleTheme } = useTheme();
  const { getAISummary } = useActivityMonitor();
  const [aiAssistant, setAiAssistant] = useState(true);
  const [notifications, setNotifications] = useState(true);
  const [autoSave, setAutoSave] = useState(true);
  const [showAIReport, setShowAIReport] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  
  const darkMode = theme === 'dark';
  const aiSummary = getAISummary();

  const getOperationDetails = (operation: OperationType) => {
    const details = {
      'terminal': {
        name: 'Terminal Operations',
        icon: Building2,
        color: 'bg-blue-500'
      },
      'courier': {
        name: 'Courier Hub',
        icon: Truck,
        color: 'bg-green-500'
      },
      'workforce': {
        name: 'Workforce Management',
        icon: Users,
        color: 'bg-purple-500'
      },
      'energy': {
        name: 'Energy Management',
        icon: Zap,
        color: 'bg-yellow-500'
      }
    };
    return details[operation] || details.terminal;
  };

  const operationDetails = getOperationDetails(operationType);

  const settingSections = [
    {
      title: 'AI & Intelligence',
      items: [
        {
          id: 'ai-activity',
          title: 'AI Activity Report',
          subtitle: `${aiSummary.totalActivities} activities monitored • ${aiSummary.predictionsGenerated} predictions`,
          icon: Activity,
          action: 'navigate',
          onClick: () => setShowAIReport(true)
        }
      ]
    },
    {
      title: `${operationDetails.name} Data`,
      items: [
        {
          id: 'import-data',
          title: 'Import Data & Configurations',
          subtitle: `Import ${operationType} operational data, templates, and settings`,
          icon: Upload,
          action: 'button',
          actionText: 'Import',
          onClick: () => setShowImportModal(true)
        },
        {
          id: 'export',
          title: 'Export Data',
          subtitle: `Download current ${operationType} dataset and configurations`,
          icon: Download,
          action: 'custom',
          customComponent: (
            <DownloadButton
              type="data"
              operationType={operationType}
              size="sm"
              className="pointer-events-auto"
            />
          )
        }
      ]
    },
    {
      title: 'Templates & Configuration',
      items: [
        {
          id: 'redesign-studio',
          title: 'System Redesign Studio',
          subtitle: 'Low-code customization and workflow builder',
          icon: Palette,
          action: 'navigate',
          onClick: () => onNavigate('redesign')
        },
        {
          id: 'templates',
          title: 'Manage Templates',
          subtitle: `${operationDetails.name} dashboard and report templates`,
          icon: FileText,
          action: 'navigate',
          count: 8,
          onClick: () => onNavigate('redesign')
        },
        {
          id: 'backup-config',
          title: 'Backup Configuration',
          subtitle: 'Save current settings and customizations',
          icon: Database,
          action: 'custom',
          customComponent: (
            <DownloadButton
              type="backup"
              operationType={operationType}
              size="sm"
              className="pointer-events-auto"
            />
          )
        }
      ]
    },
    {
      title: 'Appearance',
      items: [
        {
          id: 'customize-insights',
          title: 'Customize Dashboard Insights',
          subtitle: 'Select which KPIs and features to display',
          icon: Eye,
          action: 'navigate',
          onClick: () => onNavigate('customize')
        },
        {
          id: 'theme',
          title: 'Dark Mode',
          subtitle: 'Switch to dark theme',
          icon: darkMode ? Moon : Sun,
          action: 'toggle',
          value: darkMode,
          onChange: toggleTheme
        }
      ]
    },
    {
      title: 'Features',
      items: [
        {
          id: 'ai',
          title: 'AI Assistant',
          subtitle: 'Enable AI-powered insights',
          icon: Brain,
          action: 'toggle',
          value: aiAssistant,
          onChange: setAiAssistant
        },
        {
          id: 'notifications',
          title: 'Notifications',
          subtitle: 'System alerts and updates',
          icon: Sparkles,
          action: 'toggle',
          value: notifications,
          onChange: setNotifications
        },
        {
          id: 'autosave',
          title: 'Auto-save',
          subtitle: 'Automatically save changes',
          icon: Database,
          action: 'toggle',
          value: autoSave,
          onChange: setAutoSave
        }
      ]
    }
  ];

  const renderSettingAction = (item: any) => {
    switch (item.action) {
      case 'toggle':
        return (
          <Switch
            checked={item.value}
            onCheckedChange={item.onChange}
            className="pointer-events-auto"
          />
        );
      case 'button':
        return (
          <Button 
            variant="outline" 
            size="sm"
            className="pointer-events-auto hover:bg-accent"
            onClick={(e) => {
              e.stopPropagation();
              if (item.onClick) {
                item.onClick();
              }
            }}
          >
            {item.actionText}
          </Button>
        );
      case 'custom':
        return item.customComponent;
      case 'navigate':
        return (
          <div className="flex items-center space-x-2 pointer-events-none">
            {item.count && (
              <Badge variant="secondary" className="text-xs">
                {item.count}
              </Badge>
            )}
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <div className="bg-card border-b border-border px-4 py-4 sticky top-0 z-10">
        <div className="flex items-center space-x-3">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={() => onNavigate('home')}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-foreground">Settings</h1>
            <p className="text-muted-foreground text-sm">Configure app preferences</p>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4 space-y-6 pb-20">
        {/* App Info */}
        <Card className="border border-border bg-card">
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-red-600 rounded-xl flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div className="flex-1">
                <h2 className="text-card-foreground">Resilient Terminal Orchestrator</h2>
                <p className="text-muted-foreground text-sm">Version 1.0.0 • Honeywell Hackathon</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge className="bg-green-100 text-green-700 text-xs">Connected</Badge>
                  <div className="flex items-center space-x-1">
                    <div className={`w-3 h-3 ${operationDetails.color} rounded`}></div>
                    <Badge variant="outline" className="text-xs">{operationDetails.name}</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings Sections */}
        {settingSections.map((section) => (
          <section key={section.title}>
            <h2 className="text-foreground mb-4">{section.title}</h2>
            
            <div className="space-y-3">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <Card 
                    key={item.id} 
                    className={`border border-border transition-all duration-200 bg-card ${
                      item.onClick ? 'cursor-pointer hover:shadow-sm hover:border-primary/20' : ''
                    }`}
                    onClick={item.onClick}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                          <Icon className="h-5 w-5 text-muted-foreground" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-sm font-medium text-card-foreground">{item.title}</h3>
                          <p className="text-xs text-muted-foreground">{item.subtitle}</p>
                        </div>
                        <div onClick={(e) => {
                          // Prevent parent card click when clicking on action elements
                          if (item.action === 'toggle' || item.action === 'button') {
                            e.stopPropagation();
                          }
                        }}>
                          {renderSettingAction(item)}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        ))}

        {/* System Status */}
        <section className="pb-4">
          <h2 className="text-foreground mb-4">System Status</h2>
          
          <Card className="border border-border bg-card">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Data Source</span>
                  <Badge className="bg-green-100 text-green-700 text-xs">Connected</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Simulation Status</span>
                  <Badge className="bg-primary/10 text-primary text-xs">Running</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">AI Services</span>
                  <Badge className="bg-purple-100 text-purple-700 text-xs">Active</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Storage Used</span>
                  <span className="text-sm text-muted-foreground">2.4 MB / 50 MB</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </div>
      
      {/* AI Activity Report Modal/Overlay */}
      {showAIReport && (
        <div className="fixed inset-0 bg-background z-50">
          <AIActivityReport onBack={() => setShowAIReport(false)} />
        </div>
      )}
      
      {/* Import Modal */}
      <ImportModal 
        isOpen={showImportModal}
        onClose={() => setShowImportModal(false)}
        operationType={operationType}
      />
    </div>
  );
}