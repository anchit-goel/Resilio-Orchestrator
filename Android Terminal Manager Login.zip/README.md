
  # Android Terminal Manager Login

  This is a code bundle for Android Terminal Manager Login. The original project is available at https://www.figma.com/design/bnDIYWybI0jpG8o0S3tdaU/Android-Terminal-Manager-Login.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  